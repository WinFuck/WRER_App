Najpierw uruchom plik: "setup.exe"
i postępuj z instrukcjami.